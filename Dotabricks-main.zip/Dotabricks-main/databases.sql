-- Databricks notebook source
CREATE DATABASE bronze_dota LOCATION "/mnt/datalake/bronze/dota/";
